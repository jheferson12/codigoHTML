package com.example.kidaverage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KidAverageApplication {

    public static void main(String[] args) {
        SpringApplication.run(KidAverageApplication.class, args);
    }

}
