package com.example.kidaverage;public class Kid {
}
