package DTO;public class ErrorDTO {
}
