package DTO;public class ResponseDTO {
}
